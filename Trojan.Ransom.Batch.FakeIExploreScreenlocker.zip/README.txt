This virus is dangerous (not really, you can remove it by entering safe mode)
The password for the .exe file is iexplore
MADE FOR COME ON WINDOWS.

PAYLOADS:
When the virus is run, it creates a txt file in C:\Users\Username and a vbs file in the Startup folder.
It disables Task Manager
it shows 5 message boxes.
When 5 message boxes are answered, it bluescreens the computer.
When the computer is boot up, it shows a vbs inputbox.
explorer.exe is disabled, so you cannot remove the virus easily.
If the user give a blank decrypt key or an incorrect decrypt key, it restarts the computer.

Removal coming soon!